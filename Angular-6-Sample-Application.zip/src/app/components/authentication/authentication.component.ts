import { Component, OnInit } from '@angular/core';
import { trigger, state, animate, transition, style } from '@angular/animations';

@Component({
  selector: 'app-authentication',
  templateUrl: './authentication.component.html',
  styleUrls: ['./authentication.component.css'],
  animations: [
      trigger('fadeInOut', [
          state('void', style({
              opacity: 0
          })),
          transition('void <=> *', animate(1000)),
      ])
  ]
})
export class AuthenticationComponent implements OnInit {

  constructor() { }

  ngOnInit() {

   
  }

  onTogglerClick() {
   

  }

  onTogglerCloseClick() {
    

  }

}
