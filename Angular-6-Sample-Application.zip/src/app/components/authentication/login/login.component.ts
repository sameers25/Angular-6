import {
  Component,
  OnInit,
  ViewEncapsulation,
  ViewContainerRef
} from "@angular/core";
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl
} from "@angular/forms";


import {
  trigger,
  state,
  animate,
  transition,
  style
} from "@angular/animations";
import { DecimalPipe } from "@angular/common";
import { Router, ActivatedRoute } from "@angular/router";
declare var $: any;
@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"],
  animations: [
    trigger("fadeInOut", [
      state(
        "void",
        style({
          opacity: 0
        })
      ),
      transition("void <=> *", animate(1000))
    ])
  ]
})
export class LoginComponent implements OnInit {

  username: string = "";
  password: string = "";

  constructor( private router: Router,
    private route: ActivatedRoute,vcr: ViewContainerRef) {


  }



  ngOnInit() {

  }

  login(){
    if (this.username == "admin" && this.password == "admin") {
      this.router.navigate(["/dashboard"]);    }
  }







}
