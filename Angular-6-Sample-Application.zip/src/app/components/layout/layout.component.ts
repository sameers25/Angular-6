import { Component, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";

import { trigger, state, animate, transition, style } from '@angular/animations';
declare var $: any;

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css'],
  animations: [
    trigger('fadeInOut', [
      state('void', style({
        opacity: 0
      })),
      transition('void <=> *', animate(1000)),
    ]),
  ]
})
export class LayoutComponent implements OnInit {
  userData: any;
  loggedinUserName: string = "";
 
  clientCode: any = "";
  queryDate: any = "";
  callCentreNo: any = "";

  constructor(public router: Router,
    vcr: ViewContainerRef) {

    /*get Data for Slick Carousal*/



  }


  ngOnInit() {

  }

  checkIfQueryExist(template: TemplateRef<any>) {

    
  }


  logout() {
  
  }

  MobileMenuToggle() {
    debugger;

   $("#mobileMenuToggle").toggleClass("in");
   //var el1: HTMLElement = document.getElementById("#mobileMenuToggle");
  }






}
