import { Component, OnInit, AfterViewInit, AfterViewChecked, TemplateRef, ViewContainerRef } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';


import { trigger, state, animate, transition, style } from '@angular/animations';
declare var $: any;

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css'],
    animations: [
        trigger('fadeInOut', [
            state('void', style({
                opacity: 0
            })),
            transition('void <=> *', animate(1000)),
        ])
    ]
})

export class HomeComponent implements OnInit {

    modelRefAdd: BsModalRef;
    employeeName: string;
    employeeAge: string;
    employeeDesignation: string;
    employeeTechnology: string;
    employeeDetails: any[] = [

        {
            _id: this.newGuid(),
            employeeName: "Sameer Shaikh",
            employeeAge: "28",
            employeeDesignation: "Sr Software Engineer",
            employeeTechnology: "Angular 6",
        },
        {
            _id: this.newGuid(),
            employeeName: "Bhavesh Nikam",
            employeeAge: "25",
            employeeDesignation: " Software Engineer",
            employeeTechnology: "ASP .NET",
        },
        {
            _id: this.newGuid(),
            employeeName: "Subhash Manikanta",
            employeeAge: "28",
            employeeDesignation: "Sr Software Engineer",
            employeeTechnology: "SQL",
        }
    ];

    employeeId: string;
    employeeNameEdit: string;
    employeeAgeEdit: string;
    employeeDesignationEdit: string;
    employeeTechnologyEdit: string;



    constructor(private modalService: BsModalService, ) {


        debugger;
        this.employeeDetails;




    }



    ngOnInit() {


    }




    addEmployee(AddEmployee: TemplateRef<any>) {
        debugger;
        this.modelRefAdd = this.modalService.show(AddEmployee);
        this.employeeName = "";
        this.employeeAge = "";
        this.employeeDesignation = "";
        this.employeeTechnology = "";
    }

    navigateToResetPassword() {

    }

    closeAddPopup() {
        this.modelRefAdd.hide();
    }

    saveEmployeeDetails() {
        var employeeId = this.newGuid();
        this.employeeDetails.push({ "_id": employeeId, "employeeName": this.employeeName, "employeeAge": this.employeeAge, "employeeDesignation": this.employeeDesignation, "employeeTechnology": this.employeeTechnology })
        this.modelRefAdd.hide();
    }

    editEmployeeDetails(id, AddEmployee: TemplateRef<any>) {
        debugger;
        var result = this.employeeDetails.filter(function (v) {
            return v._id === id; // Filter out the appropriate one
        });
        this.employeeNameEdit = result[0].employeeName;
        this.employeeAgeEdit = result[0].employeeAge;
        this.employeeDesignationEdit = result[0].employeeDesignation;
        this.employeeTechnologyEdit = result[0].employeeTechnology;
        this.employeeId = result[0]._id;

        this.modelRefAdd = this.modalService.show(AddEmployee);
    }

    deleteEmployeeDetails(id, DeleteEmployee: TemplateRef<any>) {
        debugger;
        this.employeeId = id;
        this.modelRefAdd = this.modalService.show(DeleteEmployee);
        // this.employeeDetails.splice(this.employeeDetails.indexOf(id), 1);

    }


    deleteEmployee(DeleteEmployee: TemplateRef<any>) {
        debugger;
        // this.employeeDetails.splice(this.employeeDetails.indexOf(this.employeeId), 1);
        this.removeDocument(this.employeeId);
        this.modelRefAdd.hide();
    }


    updateEmployeeDetails(EditEmployee: TemplateRef<any>) {
        debugger;

        for (var i = 0; i < this.employeeDetails.length; i++) {

            if (this.employeeDetails[i]._id == this.employeeId) {

                this.employeeDetails[i].employeeName = this.employeeNameEdit;
                this.employeeDetails[i].employeeAge = this.employeeAgeEdit;
                this.employeeDetails[i].employeeDesignation = this.employeeDesignationEdit;
                this.employeeDetails[i].employeeTechnology = this.employeeTechnologyEdit;
            }
        }
        this.modelRefAdd.hide();


    }

    closeEditPopup() {
        this.modelRefAdd.hide();
    }

    newGuid() {
        return 'xxxx'.replace(/[xy]/g, function (c) {
            const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    removeDocument(doc) {
        debugger;
        this.employeeDetails.forEach((item, index) => {
            if (item._id === doc) {
                this.employeeDetails.splice(index, 1);
            }
            
        });
    }
}

