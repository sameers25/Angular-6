import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
/**Authentication Components */
import { AuthenticationComponent } from './components/authentication/authentication.component';
import { LoginComponent } from './components/authentication/login/login.component';
import { LayoutComponent } from './components/layout/layout.component';
import { HomeComponent } from './components/layout/home/home.component';
import { NotFoundComponent } from './not-found/not-found.component'

export const AppRoutes: Routes = [
    {
        path: '',
        redirectTo: 'authentication',
        pathMatch: 'full',
    },

    {
        path: '',
        component: LayoutComponent,
        children: [
            {
                path: 'dashboard',
                component: HomeComponent
            }



        ]
    },



    {
        path: 'authentication',
        component: AuthenticationComponent,
        children: [

           
            {
                path: '',
                component: LoginComponent
            },

          


        ]
    },

    
    {path: '**', redirectTo: '/404'},
    {path: '404', component: NotFoundComponent}
];





@NgModule({
    imports: [RouterModule.forRoot(AppRoutes, { useHash: true })],
    exports: [RouterModule]
})
export class AppRoutingModule {
    // constructor(private router: Router) {
    //     this.router.errorHandler = (error: any) => {
    //         this.router.navigate(['404']); // or redirect to default route
    //     }
    //   }
}